package uz.pulse.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class PulseClient implements ClientModInitializer {

    private static boolean enabled = true;
    private static KeyBinding toggleKey;

    // Sozlamalar: shularni o'zgartirib ko'ring
    private static final int   COLOR      = 0x5DAA3B; // RGB rang
    private static final int   PERIOD_MS  = 2000;     // bitta puls davomiyligi
    private static final int   MIN_ALPHA  = 40;
    private static final int   MAX_ALPHA  = 160;
    private static final int   MIN_THICK  = 2;
    private static final int   MAX_THICK  = 6;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pulsevisual.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.pulsevisual"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
            }
        });

        HudRenderCallback.EVENT.register(PulseClient::render);
    }

    private static float pulse() {
        double t = (System.currentTimeMillis() % PERIOD_MS) / (double) PERIOD_MS;
        return (float) (0.5 + 0.5 * Math.sin(t * Math.PI * 2));
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;

        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        float p = pulse();

        int alpha = MIN_ALPHA + Math.round((MAX_ALPHA - MIN_ALPHA) * p);
        int th    = MIN_THICK + Math.round((MAX_THICK - MIN_THICK) * p);
        int color = (alpha << 24) | COLOR;

        // Ekran atrofidagi pulsatsiyalanuvchi ramka
        ctx.fill(0, 0, w, th, color);
        ctx.fill(0, h - th, w, h, color);
        ctx.fill(0, th, th, h - th, color);
        ctx.fill(w - th, th, w, h - th, color);

        // Yozuv
        int textAlpha = 150 + Math.round(105 * p);
        ctx.drawTextWithShadow(mc.textRenderer, "Pulse Visual", 8, 8, (textAlpha << 24) | 0xFFFFFF);
    }
}
