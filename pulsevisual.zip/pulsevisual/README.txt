Pulse Visual - Minecraft 1.21.4 (Fabric) starter

Talablar: JDK 21, internet (Gradle kutubxonalarni yuklaydi).
Yig'ish:   gradle wrapper && ./gradlew build   (Windows: gradlew.bat build)
Natija:    build/libs/pulsevisual-1.0.0.jar -> .minecraft/mods ichiga tashlang
Kerak:     Fabric Loader 0.16+ va Fabric API 0.119.4+1.21.4
Boshqaruv: Right Shift - yoqish/o'chirish (Controls bo'limida o'zgartiriladi)
Dev rejim: ./gradlew runClient

Bulutda yig'ish (o'rnatishsiz): loyihani GitHub'ga yuklang -> Actions -> build -> Artifacts -> pulsevisual-jar
